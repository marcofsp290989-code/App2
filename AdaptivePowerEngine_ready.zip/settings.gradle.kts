rootProject.name = "AdaptivePowerEngine"
include(":app")
