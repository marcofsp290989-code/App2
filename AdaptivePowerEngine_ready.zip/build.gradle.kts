plugins { kotlin("jvm") version "1.8.21" apply false }
allprojects { repositories { google(); mavenCentral() } }
